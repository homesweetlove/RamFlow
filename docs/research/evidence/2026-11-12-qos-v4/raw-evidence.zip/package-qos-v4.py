"""Read-only derivation/archive of finished diagnostics and v4 smoke sessions."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import csv
import hashlib
import json
import shutil
import statistics
import sys
import zipfile

outer=Path(__file__).resolve().parent.parent
repo=outer/'work/RamFlow';out=outer/'outputs';prefix='RamFlow-QoS-v4'
sys.path.insert(0,str(repo/'scripts'))
from research_logcheck import check_run
from research_cpu_preflight import pressure_stable

def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def rows(p):return [json.loads(l) for l in p.read_text(encoding='utf-8-sig').splitlines()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,ensure_ascii=False,indent=2)
def utc(s):return datetime.fromisoformat(s.replace('Z','+00:00'))
def pct(values,q):
    values=sorted(values);n=(len(values)-1)*q;lo=int(n);hi=min(lo+1,len(values)-1)
    return values[lo]+(values[hi]-values[lo])*(n-lo)

root=repo/'work/real-app-abc-smoke-v4-20261112'
analysis=read(repo/'work/real-app-abc-analysis-v4-20261112/smoke-summary.json')
assert analysis['smoke_passed'] and all(analysis['matched_B_C_readbacks'].values())
plan=read(root/'pilot-plan.json');sessions=[];checks=[];sources=[]
for slot in plan['schedule']:
    d=root/slot['session'];check=check_run(d);assert check['ok'] and check['status']=='completed',check;checks.append(check)
    o=read(d/'outcome.json');m=read(d/'run-manifest.json');s=read(d/'source-manifest.json');events=rows(d/'trial-events.jsonl')
    assert s['Commit']=='bff7583801c2a09beaf352673de10256e652e08a' and s['Dirty'] is False
    get=lambda kind:[r['data'] for r in events if r['kind']==kind]
    obs=get('app-observation');assert len(obs)==o['observations'] and all(x['correct'] for x in obs)
    assert o['restored'] and o['workload_restored'] and o['cleanup_completed'] and o['protected_misinterventions']==0 and o['readback_failures']==0
    cleanup=get('app-cleanup');assert len(cleanup)==1 and cleanup[0]['cleanup']['completed'] and cleanup[0]['cleanup']['remaining_pids']==[]
    timing=read(d/'overhead-summary.json');dec=timing.get('policy_timing_ms') or [];audit=timing.get('audit_write_ms') or []
    row=dict(**slot,requests=len(obs),status=o['status'],source_commit=s['Commit'],source_dirty=s['Dirty'],controller_sha256=m['controller_sha256'],core_sha256=m['core_sha256'],
        started_kst=utc(m['created_utc']).astimezone(timezone(timedelta(hours=9))).isoformat(),applies=o['applies'],restored=o['restored'],workload_restored=o['workload_restored'],cleanup_completed=o['cleanup_completed'],
        protected_misinterventions=o['protected_misinterventions'],readback_failures=o['readback_failures'],workload_initial=read(d/'workload-original.json'),workload_effective=read(d/'workload-effective.json'),
        workload_final=read(d/'workload-final.json'),policy_final=read(d/'resource-final.json'),policy_writes=get('resource-write-readback'),workload_writes=get('workload-write-readback'),
        interventions_and_restores=[dict(time_utc=e['time_utc'],**e['data']) for e in events if e['kind']=='engine-event' and e['data']['entry']['Kind'] in ('apply','restore')],
        decision_count=len(dec),decision_p50_ms=pct(dec,.5) if dec else None,decision_p95_ms=pct(dec,.95) if dec else None,decision_max_ms=max(dec,default=None),
        audit_count=len(audit),audit_p50_ms=pct(audit,.5) if audit else None,audit_p95_ms=pct(audit,.95) if audit else None,journal_wall_ms=read(d/'completion.json')['log_write_ms'])
    if slot['condition']=='A':assert not row['policy_writes']
    assert len(row['workload_writes'])==2
    recovery_start=next(e for e in events if e['kind']=='phase-start' and e['data']['phase']=='Recovery')
    recovery_restores=[e for e in row['interventions_and_restores'] if e['phase']=='Recovery' and e['entry']['Kind']=='restore']
    row['last_recovery_restore_delay_seconds']=(utc(recovery_restores[-1]['time_utc'])-utc(recovery_start['time_utc'])).total_seconds() if recovery_restores else None
    sessions.append(row)
assert len(sessions)==6 and len({s['controller_sha256'] for s in sessions})==1 and len({s['core_sha256'] for s in sessions})==1
admission=repo/'work/cpu-normal-qos-admission-20261112';a=read(admission/'result.json');astart=read(admission/'started.json')
assert a['passed'] and a['cleanup'] and a['restored'] and astart['qos_mode']=='normal' and astart['controller_binary_sha256']==sessions[0]['controller_sha256']
assert pressure_stable([r['cpu_percent'] for r in a['samples'] if r['phase']=='Contention'])

diagnostics=[]
for name in ['cpu-readonly-diagnostic-20261112','cpu-qos-owned-probe-20261112']:
    d=repo/'work'/name;index=read(d/'artifact-index.json')
    for f in index['files']:
        p=d/f['path'];assert p.stat().st_size==f['bytes'] and sha(p)==f['sha256']
    sample=rows(d/'samples.jsonl');phases={}
    for phase in dict.fromkeys(r['phase'] for r in sample):
        r=[x for x in sample if x['phase']==phase]
        values=[x['system_time_cpu_percent'] for x in r]
        phases[phase]=dict(samples=len(r),system_time_cpu_min=min(values),system_time_cpu_max=max(values),system_time_cpu_mean=statistics.mean(values),
            last_sampled_processors=sorted({w['sampled_last_processor'] for x in r for w in x['worker_reply']['Telemetry']['workers'] if w['sampled_last_processor'] is not None}),
            explicit_qos=sorted({(x['worker_reply']['Telemetry']['values']['PowerControl'],x['worker_reply']['Telemetry']['values']['PowerState']) for x in r}))
    diagnostics.append(dict(directory=name,result=read(d/'result.json'),phases=phases,index_verified=True,profile=index['profile']))

summary=dict(protocol=plan['protocol'],input_stratum='All A/B/C use explicitly normal execution-speed QoS workload; A has no engine/tray. Not OS-default workload QoS.',
    source_commit=sessions[0]['source_commit'],sessions=sessions,total_foreground_requests=sum(s['requests'] for s in sessions),smoke_passed=True,matched_B_C_readbacks=analysis['matched_B_C_readbacks'],diagnostics=diagnostics,
    admission_result=a,admission_started=astart,metrics=analysis['metrics'],overheads=analysis['overheads'],
    inference='One session per app/condition, single PC. No CI, superiority, equivalence, main-study N or journal acceptance inference. Default-QoS historical protocols remain separate.')
save(out/(prefix+'-summary.json'),summary);save(out/(prefix+'-integrity.json'),dict(runs=checks,diagnostic_indices_verified=True))
for source,target in [('metrics.csv','metrics.csv'),('overheads.csv','overheads.csv')]:
    with (out/(prefix+'-'+target)).open('xb') as f:f.write((repo/'work/real-app-abc-analysis-v4-20261112'/source).read_bytes())
with (out/(prefix+'-verification.txt')).open('xb') as f:f.write((repo/'work/v4-verification-20261112.txt').read_bytes())

archive=out/(prefix+'-evidence.zip')
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for slot in plan['schedule']:
        for f in sorted((root/slot['session']).rglob('*')):
            if f.is_file():z.write(f,'v4/'+f.relative_to(root).as_posix())
    for f in sorted(root.iterdir()):
        if f.is_file():z.write(f,'v4/'+f.name)
    for d,label in [(admission,'admission')]+[(repo/'work'/x['directory'],x['directory']) for x in diagnostics]:
        for f in sorted(d.rglob('*')):
            if f.is_file():z.write(f,label+'/'+f.relative_to(d).as_posix())
    z.write(Path(__file__),'package-qos-v4.py')
save(out/(prefix+'-archive.json'),dict(bytes=archive.stat().st_size,sha256=sha(archive),note='SHA256 detects changes against this inventory; not an external signature or timestamp. Runtime profiles excluded, original sealed session files retained.'))

metric=lambda app,condition,feature:next(x for x in analysis['metrics'] if x['app']==app and x['condition']==condition and x['phase']=='Contention' and x['feature']==feature)
lines=['# RAM Flow QoS 진단과 v4 실앱 연결 검증', '',
'2026-11-12 KST · 단일 PC · 앱/조건당 1세션. **6/6 스모크 연결 검증 통과**. 총 '+str(summary['total_foreground_requests'])+'개 전경 요청은 독립 실험 반복이 아니다. 성능 우위·동등성·KCI 게재 가능성은 이 결과로 확정하지 않는다.', '',
'## 이번에 실제 구현한 부분', '',
'읽기 전용 스레드/코어/PDH 진단, 생성한 자식 PID+정확한 생성 FILETIME에 한정한 QoS 대조 도구, 지속 CPU 부하 입장 검사와 바이너리 해시 결속, 새 v4 입력층을 추가했다. 정책 기준선 복원과 공통 워크로드 초기값 복원을 별도 저널·readback으로 검증한다. 제품 V1/Engine의 임계값과 판단 로직은 변경하지 않았다.', '',
'## 사전 진단과 입력 조건', '',
'기본 QoS의 14개 계산 작업자는 진행 중이었지만 마지막 실행 위치 샘플이 효율 클래스 0인 논리 코어 12~15에 모였다. 동일 PID의 기본 상태→명시적 정상 QoS→기본값 복원 대조에서 CPU와 샘플 위치가 가역적으로 바뀌었다. 마지막 위치는 연속 실행 추적이 아니며 시스템 전체 실행 큐를 이 작업에 모두 귀속하지 않는다. 명시 API의 0/0은 효과적인 OS QoS 분류를 알려주지 않고, immediate Job 정보는 상위 Job 제한을 배제하지 않는다.', '',
'| 동일 소유 PID 진단 구간 | 전체 CPU 범위 | QoS Control/State |', '|---|---:|---:|']
probe=diagnostics[1]['phases']
for name in ['default-qos','normal-qos','default-restored']:
    p=probe[name];lines.append(f"| {name} | {p['system_time_cpu_min']:.1f}–{p['system_time_cpu_max']:.1f}% | {p['explicit_qos']} |")
lines+=['', '이 PC/부하의 대조 관측이다. Windows는 QoS에 따라 코어 선택과 전력 관리를 달리할 수 있다. [Microsoft QoS](https://learn.microsoft.com/en-us/windows/win32/procthread/quality-of-service), [SetProcessInformation](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-setprocessinformation).', '',
'v4는 **모든 A/B/C에 동일한 명시적 정상 QoS 워크로드**를 넣은 별도 조건이다. A는 엔진/트레이 미실행이며 워크로드 QoS까지 Windows 기본인 조건은 아니다. 공통 초기화는 CPU/메모리 우선순위나 affinity를 바꾸지 않는다. Normal→Contention→Recovery 활성 작업자 수는 1→14→1, 작업 단위는 xorshift64-1000000-v1:normal-qos이며 체크섬 bd2eeae7775b742c를 확인했다. 기본 QoS v2/v3의 실패/무개입 데이터와 합치거나 대체하지 않았다.', '',
'새 사전 검사 CPU 표본은 '+str([r['cpu_percent'] for r in a['samples'] if r['phase']=='Contention'])+'%. 지속 기준과 초기 설정 복원·정리 모두 통과했다.', '',
'진단 원본은 5bd790b 기반 dirty 개발 스냅샷과 해시를 보존한다. QoS probe의 원본 inference 문자열에 read-only라는 이전 문구가 남아 있지만 실제 profile/이벤트/결과는 쓰기 2회를 명시한다. 이 문구를 사후 수정하지 않았다. v4 본 실행 소스는 clean `'+sessions[0]['source_commit']+'`이며 6세션의 controller/core 해시가 같다.', '',
'## 관측한 성능: Contention 구간', '',
'아래는 단일 세션 내 p95이며 블록별 중앙값이나 효과 검정이 아니다. Chrome은 클릭 핸들러→두 번째 rAF, VS Code는 completion/save API 지연이다. 물리적 키 입력→화면 표시 지연으로 해석하지 않는다.', '',
'| 앱·기능 | A 미실행 p95 ms | B 고정 p95 ms | C V1 p95 ms |', '|---|---:|---:|---:|']
for app,feature in [('chrome','search'),('chrome','sort'),('code','completion'),('code','save')]:
    lines.append('| '+app+' '+feature+' | '+' | '.join(f"{metric(app,c,feature)['p95_ms']:.2f}" for c in 'ABC')+' |')
lines+=['', '| 배경 처리율 (완료 단위/초) | A | B | C |', '|---|---:|---:|---:|']
for app,feature in [('chrome','search'),('code','completion')]:
    lines.append('| '+app+' | '+' | '.join(f"{metric(app,c,feature)['background_units_per_second']:.1f}" for c in 'ABC')+' |')
lines+=['', 'Chrome의 세 조건 지연은 매우 비슷했다. VS Code에서 B는 C보다 낮은 completion p95를 보였고 C는 더 많은 배경 처리량을 보존했다. 따라서 **같은 응답성에서 처리량 우위라는 주장은 아직 입증되지 않았다**. Recovery의 C 배경 처리율은 Chrome '+f"{next(x for x in analysis['metrics'] if x['session']=='chrome-C' and x['phase']=='Recovery')['background_units_per_second']:.1f}"+' / Code '+f"{next(x for x in analysis['metrics'] if x['session']=='code-C' and x['phase']=='Recovery')['background_units_per_second']:.1f}"+' 단위/초였다. B는 Recovery에도 고정 제한을 유지한다. 실행 시간이 정해진 스트리밍 부하이므로 작업 전체 완료시간은 측정하지 않았다.', '',
'## 적용·복원과 안정성', '',
'B/C의 활성 OS readback은 두 앱에서 모두 CPU 0x4000(BelowNormal), 메모리 우선순위 3, QoS Control/State=1/1, CPU Sets=[]로 일치했다. 공통 입력 기준선은 CPU 32(Normal), 메모리 5, QoS 1/0이고, 실행 전 워크로드 원본 0/0까지 별도로 복원했다. A의 정책 쓰기는 0회이며 공통 워크로드 초기화/복원 쓰기 2회는 별도 표기했다.', '',
'| 세션 | 요청 | 정책 적용 | Recovery 마지막 복원 지연 초 |', '|---|---:|---:|---:|']
for s in sessions:lines.append(f"| {s['session']} | {s['requests']} | {s['applies']} | "+(f"{s['last_recovery_restore_delay_seconds']:.3f}" if s['last_recovery_restore_delay_seconds'] is not None else '해당 없음')+' |')
lines+=['', 'Chrome C는 Contention에서 적용/복원을 9/8회 반복하고 Recovery에서 마지막 복원했다. Code C는 Contention에서 7/7회, Recovery 초입에서 1/1회 적용/복원했다. 압박 해제에 따른 반복 전환과 Recovery 지연 개입은 V1의 안정성 한계다. 완료 판정은 회복 구간 안 복원과 원본 readback을 충족했다는 뜻이며, 무진동 정책이라는 뜻이 아니다. 원시 타임라인을 그대로 보존한다.', '',
'모든 전경 결과 정확성 확인, 보호 전경 오개입 0, readback 불일치 0, 원복 실패 0, 소유 Job 정리 완료 및 남은 PID 0이었다. fd17548 계열 무결성 검사에서 원시 응답/백분위수/처리율/완료 마커/파일 해시와 v4 두 단계 복원을 재검증했다. 실패 데이터는 이전 증거 묶음 그대로 보존한다.', '',
'## 실제 오버헤드 예시: Code C', '',
'CPU는 16개 논리 CPU 전체 대비 평균 %, 메모리는 해당 구간 최대 MiB. 엔진은 실행기와 같은 프로세스이므로 엔진 단독 비용이 아니다. 원시 표본 수·모든 세션/단계 값은 overheads.csv에 있다.', '',
'| 단계 | 프로세스 역할 | CPU % | Private MiB | Working Set MiB |', '|---|---|---:|---:|---:|']
for p in ['Normal','Contention','Recovery']:
    for role in ['engine-and-controller','tray','app-driver','observer']:
        r=next(x for x in analysis['overheads'] if x['session']=='code-C' and x['phase']==p and x['role']==role)
        lines.append(f"| {p} | {role} | {r['cpu_percent_mean']:.3f} | {r['private_bytes_max']/2**20:.2f} | {r['working_set_bytes_max']/2**20:.2f} |")
lines+=['', '| 세션 | 결정 p50 / p95 ms | 감사 쓰기 p95 ms | 전체 저널 쓰기 누적 ms |', '|---|---:|---:|---:|']
for s in sessions:
    dec=f"{s['decision_p50_ms']:.4f} / {s['decision_p95_ms']:.4f}" if s['decision_p50_ms'] is not None else '엔진 미실행'
    audit=f"{s['audit_p95_ms']:.4f}" if s['audit_p95_ms'] is not None else '해당 없음'
    lines.append(f"| {s['session']} | {dec} | {audit} | {s['journal_wall_ms']:.2f} |")
lines+=['', '누적 쓰기 벽시계 시간은 CPU 사용량이 아니다. 결정 시간 표본에는 보호 대상 평가도 포함된다. 서비스는 미실행이며 A 트레이/엔진은 미실행으로 기록한다. 순수 Idle, 관측 전용, 활성 평가, 실제 제한, 복원 상태를 각각 격리한 오버헤드 실험은 아직 아니다. 짧은 복원만의 비용을 샘플링 구간에서 분리해 주장하지 않는다. Python 레거시 대비 개선 주장도 하지 않는다.', '',
'## 검증과 재현', '',
'로컬: ResearchLab/Tray Release 빌드 경고·오류 0. 앱 계약 14, 지속 부하 입장 5, Windows CPU fixture 2, 소유 QoS 2, 로그 무결성 10 테스트 통과. 별도 Windows ResearchLab 통합과 로깅 실패/취소 통합도 통과했다. 실앱 6세션과 압박 진단은 단위 테스트와 구분한다.', '',
'커밋 bff7583의 [Windows Native CI](https://github.com/homesweetlove/RamFlow/actions/runs/43148479476) 및 [제품 Windows 빌드 CI](https://github.com/homesweetlove/RamFlow/actions/runs/43148479412) 성공. Native Windows API 515 / IPC 525 assertion 누적 통과. 관련 Python 검사와 새 소유 PID QoS 테스트, Windows 연구/로깅 통합도 CI에서 통과했다.', '',
'실행 명령은 docs/research/REAL_APP_ABC_SMOKE.ko.md에 있다. 패키지의 v4/ 각 세션을 `python scripts/research_logcheck.py --input <추출경로>/v4 --recursive`로 재검사할 수 있다. Windows 경로 길이 문제를 피하도록 짧은 추출 루트를 사용한다. ZIP 내 package-qos-v4.py는 파생 요약/아카이브 생성 절차를 기록한다. SHA256은 무결성 비교이며 외부 서명/타임스탬프가 아니다.', '',
'## 논문 전에 남은 것', '',
'현재 달성은 실앱 비교 경로·측정·복원·무결성의 1회 연결 검증이다. CARP의 우수성 검증이나 논문 실험 완료가 아니다. 다음은 독립 세션 블록 반복과 순서 균형, V1 반복 전환의 원인/비용 평가, 같은 지연 목표에서 배경 처리율 비교, 입력 QoS 두 층의 사전 명시다. 이후 실물 8/16/24GB+ 장비, CPU/RAM/혼합/정상 환경, 실제 빌드 등 유한 작업 완료시간, 재활성화·페이지 재접근·starvation 및 CARP 예측 검증/소거 분석이 필요하다. System Pages Input을 per-process Hard Fault로 쓰지 않는다.', '',
'본실험 전에 지연 허용 범위·실패 조건·가설·정책/모델·분석 계획·반복 수를 독립 파일럿에 근거해 고정해야 한다. 세션 내 요청을 반복 수로 늘리거나 같은 전경 응답성 달성을 가정하지 않는다. 실패/회귀/효과 없는 조건도 포함하며 게재를 보장하지 않는다.', '',
'작업 브랜치 research/carp, [Draft PR #4](https://github.com/homesweetlove/RamFlow/pull/4). main/research/kci-baseline 및 과거 원본은 보존했다.', '']
with (out/(prefix+'-report.ko.md')).open('x',encoding='utf-8') as f:f.write('\n'.join(lines))
print(json.dumps(dict(sessions=6,requests=summary['total_foreground_requests'],zip_bytes=archive.stat().st_size,zip_sha256=sha(archive)),indent=2))
