using System.Diagnostics;
using System.Text.Json;
using RamFlow.Core;

namespace ResearchLab;

static class Options
{
    public static string Get(string[] args, string key, string fallback) { int at = Array.LastIndexOf(args, key); return at >= 0 && at + 1 < args.Length ? args[at + 1] : fallback; }
    public static string[] Replace(string[] args, string key, string value) { var list = new List<string>(); for (int i = 0; i < args.Length; i++) {
        if (args[i] == key) { i++; continue; } list.Add(args[i]); } list.Add(key); list.Add(value); return list.ToArray(); }
    public static int Seed(string[] args) => (int)(ulong.Parse(Get(args, "--seed", "1"), System.Globalization.CultureInfo.InvariantCulture) % int.MaxValue);
    public static int Int(string[] args, string key, int fallback, int min, int max) { int value = int.Parse(Get(args, key, fallback.ToString())); if (value < min || value > max) throw new ArgumentException($"{key} must be {min}..{max}."); return value; }
    public static void NewDirectory(string path) { if (File.Exists(path) || Directory.Exists(path)) throw new IOException("Preserve the existing run; choose a new output directory."); Directory.CreateDirectory(path); }
    public static void WriteNew<T>(string path, T value) { using var file = new FileStream(path, FileMode.CreateNew); JsonSerializer.Serialize(file, value, new JsonSerializerOptions { WriteIndented = true }); file.Flush(true); }
    public static string Hardware(Snapshot s) => FileResearchAuditSink.Hash(new { s.RamTotal, Environment.ProcessorCount,
        Cpu = Microsoft.Win32.Registry.GetValue(@"HKEY_LOCAL_MACHINE\HARDWARE\DESCRIPTION\System\CentralProcessor\0", "ProcessorNameString", "unknown"),
        Os = Environment.OSVersion.VersionString, Runtime = Environment.Version.ToString(), Architecture = System.Runtime.InteropServices.RuntimeInformation.ProcessArchitecture.ToString() });
    public static object CaptureSources(string directory) {
        var root = new DirectoryInfo(AppContext.BaseDirectory); while (root is not null && !System.IO.Directory.Exists(Path.Combine(root.FullName, ".git"))) root = root.Parent;
        if (root is null) return new { Status = "unavailable", Note = "No Git checkout found; binary hashes remain recorded." };
        string Query(params string[] args) { var start = new ProcessStartInfo("git") { UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true };
            start.ArgumentList.Add("-C"); start.ArgumentList.Add(root.FullName); foreach (string arg in args) start.ArgumentList.Add(arg);
            using var process = Process.Start(start)!; string text = process.StandardOutput.ReadToEnd(); process.WaitForExit(); return process.ExitCode == 0 ? text.Trim() : "unavailable"; }
        var files = new Dictionary<string, string?>();
        foreach (string relative in new[] { "native/RamFlow.Core", "scripts/ResearchLab" }) foreach (string path in System.IO.Directory.GetFiles(Path.Combine(root.FullName, relative), "*", SearchOption.TopDirectoryOnly)
            .Where(x => x.EndsWith(".cs") || x.EndsWith(".csproj"))) {
            string name = Path.GetRelativePath(root.FullName, path), target = Path.Combine(directory, "source", name); System.IO.Directory.CreateDirectory(Path.GetDirectoryName(target)!);
            File.Copy(path, target); files[name] = FileResearchAuditSink.FileHash(target);
        }
        return new { Status = "recorded", Commit = Query("rev-parse", "HEAD"), Dirty = Query("status", "--porcelain") != "", SourceFilesSha256 = FileResearchAuditSink.Hash(files), Files = files };
    }
}

static class LabProfiles
{
    public static CarpOptions Options(string variant) {
        if (variant == "None") return new();
        // The policy owns the approved profiles. Never manufacture safety-off
        // options from CLI names or silently fall back to an unknown profile.
        if (!Enum.TryParse<CarpAblation>(variant, false, out var selected) || !Enum.IsDefined(selected))
            throw new ArgumentException("Unknown CARP ablation profile.");
        var options = new CarpOptions { Ablation = selected }; CarpOptions.Validate(options); return options;
    }
}

sealed class OwnedProvider : IResourceProvider
{
    readonly WindowsResourceProvider real = new(); readonly FixtureChild foreground, background;
    public int OutOfScopeRequests { get; private set; }
    public bool ProbeForeground { get; set; }
    public OwnedProvider(FixtureChild foreground, FixtureChild background) { this.foreground = foreground; this.background = background; }
    public Snapshot Sample() => real.Sample();
    public IReadOnlyList<ProcessSample> Processes() => real.Processes().Where(x => x.Pid == background.Process.Id && x.Identity == background.Identity).ToArray();
    public (int Pid, string Name) Foreground() { var p = ProbeForeground ? background.Process : foreground.Process; return (p.Id, p.ProcessName + ".exe"); }
    public bool Fullscreen() => false;
    public IReadOnlyList<CpuCore> Topology() => real.Topology();
    public long? Identity(int pid) => real.Identity(pid);
    public bool Exited(int pid) => real.Exited(pid);
    bool Owns(int pid, long identity) => pid == background.Process.Id && identity == background.Identity;
    public bool Validate(ProcessSample target, bool restoring = false) => Owns(target.Pid, target.Identity) && real.Validate(target, restoring);
    public ResourceValues? ReadValues(int pid) => pid == background.Process.Id ? real.ReadValues(pid) : null;
    public bool WriteValues(int pid, ResourceValues values, long identity) { if (!Owns(pid, identity)) { OutOfScopeRequests++; return false; } return real.WriteValues(pid, values, identity); }
    public bool Trim(int pid, long identity) { OutOfScopeRequests++; return false; }
    public ulong? WorkingSet(int pid, long identity) => Owns(pid, identity) ? real.WorkingSet(pid, identity) : null;
    public void Dispose() => real.Dispose();
}

sealed class CandidatePolicy(ResourceAction action) : IResourcePolicy
{
    public string Name => "measured-candidate";
    public string Version => "1.0";
    public PolicyDecision Decide(PolicyInput input) {
        string? protection = PolicySafety.Protection(input, explicitOnly: true);
        return new(protection is null ? action : ResourceAction.None, protection ?? "calibration-candidate-only", PolicySafety.Classify(input), []);
    }
}

sealed class TimedAudit : IResearchAuditSink, IDisposable
{
    readonly FileResearchAuditSink sink;
    public List<double> DecisionMs { get; } = [];
    public List<double> WriteMs { get; } = [];
    public List<string> RestoreResults { get; } = [];
    public int Applies { get; private set; }
    public TimedAudit(string path, string commit) { sink = new(path, commit); }
    public void Write(ResearchAuditEvent entry) {
        var clock = Stopwatch.StartNew(); sink.Write(entry); WriteMs.Add(clock.Elapsed.TotalMilliseconds);
        if (entry.Kind == "decision" && entry.Detail is not null) {
            var detail = JsonSerializer.SerializeToElement(entry.Detail);
            if (detail.TryGetProperty("DecisionElapsedMs", out var time)) DecisionMs.Add(time.GetDouble());
        }
        if (entry.Kind == "apply" && entry.Result == "applied") Applies++;
        if (entry.Kind == "restore") RestoreResults.Add(entry.Result);
    }
    public void Dispose() => sink.Dispose();
}

sealed class ResourceObserver : IDisposable
{
    readonly Dictionary<int, (double Cpu, long Stamp)> previous = new();
    readonly StreamWriter raw;
    public List<object> Samples { get; } = [];
    public ResourceObserver(string path) { raw = new(new FileStream(path, FileMode.CreateNew)) { AutoFlush = true }; }
    public void Sample(Process process, string phase, string role, double? decision = null, double? log = null) {
        try {
            process.Refresh(); long stamp = Stopwatch.GetTimestamp(); double cpu = process.TotalProcessorTime.TotalSeconds;
            double? percent = previous.TryGetValue(process.Id, out var before) ?
                Math.Max(0, (cpu - before.Cpu) / ((stamp - before.Stamp) / (double)Stopwatch.Frequency) / Environment.ProcessorCount * 100) : null;
            previous[process.Id] = (cpu, stamp);
            var sample = new { time_utc = DateTimeOffset.UtcNow, pid = process.Id, creation_filetime = process.StartTime.ToFileTimeUtc(), phase, role,
                cpu_percent = percent, private_bytes = process.PrivateMemorySize64, working_set_bytes = process.WorkingSet64,
                decision_ms = decision, log_write_ms = log };
            Samples.Add(sample); raw.WriteLine(JsonSerializer.Serialize(sample));
        } catch (Exception e) { raw.WriteLine(JsonSerializer.Serialize(new { phase, role, error = e.Message, status = "unavailable" })); }
    }
    public void Dispose() => raw.Dispose();
}
