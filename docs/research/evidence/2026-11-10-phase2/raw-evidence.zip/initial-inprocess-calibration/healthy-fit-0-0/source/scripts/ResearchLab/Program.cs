using System.Diagnostics;
using System.Text.Json;
using RamFlow.Core;
using ResearchLab;

if (!OperatingSystem.IsWindows()) { Console.Error.WriteLine("ResearchLab requires Windows; no measurements were generated."); return 2; }
try {
    if (args.Length == 0) throw new ArgumentException("Use worker | trial | calibrate | train | validate.");
    if (args[0] == "worker") return await FixtureWorker.Run(args);
    if (args[0] == "train") {
        string root = Path.GetFullPath(Options.Get(args, "--input", "")), output = Path.GetFullPath(Options.Get(args, "--model", ""));
        var rows = Directory.GetFiles(root, "cost-observation.json", SearchOption.AllDirectories)
            .Select(path => JsonSerializer.Deserialize<CostObservation>(File.ReadAllText(path))!).ToArray();
        var model = CostModelTrainer.Train(rows); CostModelTrainer.SaveNew(model, output);
        Console.WriteLine(JsonSerializer.Serialize(new { model.ModelId, Cells = model.Cells.Length, Accepted = model.Cells.Count(x => x.Accepted),
            Note = "A model with zero accepted cells is a preserved calibration failure, not a useful controller." })); return 0;
    }
    if (args[0] == "validate") {
        var model = CostModelTrainer.Load(Options.Get(args, "--model", ""));
        string directory = Path.GetFullPath(Options.Get(args, "--output", "")); Options.NewDirectory(directory);
        Options.WriteNew(Path.Combine(directory, "validation.json"), new { model.ModelId, model.DatasetSha256, model.FitBlockIds,
            model.ValidationBlockIds, model.Cells, Note = "Held-out calibration diagnostics, not final policy superiority." });
        return 0;
    }
    if (args[0] == "trial") { var result = await Trial.Run(args); Console.WriteLine(JsonSerializer.Serialize(result)); return result.Status == "completed" ? 0 : 1; }
    if (args[0] == "calibrate") {
        string root = Path.GetFullPath(Options.Get(args, "--output", "")); Options.NewDirectory(root);
        int fit = Options.Int(args, "--fit-blocks", 3, 3, 100), validation = Options.Int(args, "--validation-blocks", 3, 3, 100);
        string[] regimes = Options.Get(args, "--regimes", "cpu,ram,mixed,healthy").Split(',');
        if (regimes.Any(x => x is not ("cpu" or "ram" or "mixed" or "healthy"))) throw new ArgumentException("Unknown intended regime.");
        int[] actions = Options.Get(args, "--actions", "0,1,3,4,5,7").Split(',').Select(int.Parse).ToArray();
        if (!actions.Contains(0) || actions.Distinct().Count() != actions.Length || actions.Any(x => x is not (0 or 1 or 3 or 4 or 5 or 7))) throw new ArgumentException("Include a unique no-action baseline and valid candidates.");
        int seed = Options.Int(args, "--seed", 20261110, 0, int.MaxValue); var random = new Random(seed);
        Options.WriteNew(Path.Combine(root, "manifest.json"), new { Seed = seed, FitBlocks = fit, ValidationBlocks = validation, Regimes = regimes, Actions = actions,
            Scope = "Disposable synthetic task calibration; observed regime may differ from intended pressure. No global memory purge or user app modification." });
        var results = new List<object>(); int failure = 0;
        foreach (string regime in regimes) for (int n = 0; n < fit + validation; n++) {
            string split = n < fit ? "fit" : "validation", block = Guid.NewGuid().ToString("N"); int blockSeed = random.Next();
            foreach (int action in actions.OrderBy(_ => random.Next())) {
                var childArgs = args.Concat(new[] { "--condition", "calibration", "--candidate", action.ToString(), "--block", block,
                    "--split", split, "--regime", regime, "--seed", blockSeed.ToString() }).ToArray();
                // Last occurrence wins for generated immutable trial options.
                childArgs = Options.Replace(childArgs, "--output", Path.Combine(root, $"{regime}-{split}-{n}-{action}"));
                var result = await Trial.Run(childArgs); results.Add(new { result.Status, result.Directory, result.Regime, result.RegimeAttained });
                if (result.Status != "completed") failure++;
                Console.WriteLine($"{regime} {split} block {n + 1} action {action}: {result.Status}; observed {result.Regime}");
            }
        }
        Options.WriteNew(Path.Combine(root, "run.result.json"), new { Status = failure == 0 ? "completed" : "incomplete", Failures = failure, Trials = results }); return failure == 0 ? 0 : 1;
    }
    throw new ArgumentException("Unknown ResearchLab mode.");
} catch (Exception error) { Console.Error.WriteLine(error); return 2; }
